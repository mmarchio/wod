<?php
namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Cache\Simple\FilesystemCache;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use AppBundle\Service\DB;

class UiController extends Controller
{
    const dbg = "<html><head></head><body></body></html>";

    /**
     * @Route("/ui/chronicle/create")
     */
    final public function UiChronicleCreate(Request $request): Response
    {
        return $this->render('@App/form.chronicle.html.twig', ["data" => ["env" => $this->getEnv($request)]]);
    }

    /**
     * @Route("/ui/chronicle/list")
     */
    final public function UiChronicleList(): Response
    {
        $db = $this->initDb();

        $r = $db->q("SELECT uuid, version_set_uuid, content FROM content WHERE content_type = 'Chronicle'");
        dump($r);
        return new Response("<html><head></head><body></body></html>");
    }

    /**
     * @Route("/ui/character-trait/create")
     * @param Request $request
     * @return Response
     */
    final public function UiTraitCreate(Request $request): Response
    {
        $db = $this->initDb();
        $baseData = $this->baseTraitData();

        return $this->render('@App/form.trait.html.twig', ["data" => [
            "env" => $this->getEnv($request),
            "traits" => $baseData->traits,
            "types" => $baseData->types,
            "categories" => $baseData->categories,
            "subCategories" => $baseData->subCategories,
            "org" => $baseData->traitOrg,
            "route" => "api/character-trait/create"
        ]]);

    }

    /**
     * @Route("/ui/tag/create")
     * @param Request $request
     * @return Response
     */
    final public function UiTagCreate(Request $request): Response
    {
        $db = $this->initDb();
        $tags = $db->q("SELECT DISTINCT type, type_uuid FROM tag");
        $types = $db->q("SELECT DISTINCT content_type, value FROM index_tag WHERE field = 'type'");
        $data = [
            "env" => $this->getEnv($request),
            "content_types" => [],
            "tag_types" => $tags
        ];
        $c = count($types);
        for ($i=0; $i<$c; $i++) {
            $type = new \stdClass();
            $type->name = $types[$i]["value"];
            $type->content = $db->q("SELECT * FROM index_tag WHERE content_type = '".$types[$i]['content_type']."'");
            $type->content = $this->filterByUuid($type->content);
            $type->content = $this->filterByType($type->content, $type->name);
            $type->content = $this->orderByName($type->content);
            $data["content_types"][] = $type;
        }
        dump($data);
        return $this->render('@App/form.tag.html.twig', ["data" => $data]);
    }

    /**
     * @Route("/ui/character-creation-rule/create")
     * @param Request $request
     * @return Response
     */
    final public function UiCharacterCreationRuleCreate(Request $request): Response
    {
        $data = ["env" => $this->getEnv($request)];
        return $this->render('@App/form.character_creation_rule.html.twig', ["data" => $data]);
    }

    /**
     * @Route("/ui/type-restriction/create")
     * @param Request $request
     * @return Response
     */
    final public function UiTypeRestrictionCreate(Request $request): Response
    {
        $data = ["env" => $this->getEnv($request)];
        $db = $this->initDb();
        $types = $db->q("SELECT content_type_uuid FROM index_tag WHERE field = 'type' AND value = 'Entity'");
        $subtypes = [];
        foreach ($types as $type) {
            $typeName = $db->q("SELECT value FROM index_tag WHERE field = 'name' AND content_type_uuid = '".$type['content_type_uuid']."'");
            $associationLookup = $db->q("SELECT child_uuid FROM tag WHERE parent_uuid = '".$type['content_type_uuid']."'");
            $associations = [];
            foreach ($associationLookup as $association) {
                $content = $db->q("SELECT uuid, content FROM content WHERE uuid='".$association["child_uuid"]."'");
                $associations[] = ["uuid" => $content[0]['uuid'], "content" => unserialize(base64_decode($content[0]['content']))];
            }
            $subtypes[$typeName[0]['value']] = $associations;
        }
        $traits = $db->q("SELECT content_type_uuid FROM index_tag WHERE field = 'name'");
        $fullTraits = [];
        foreach ($traits as $trait) {
            $fullTrait = $db->q("SELECT content FROM content WHERE uuid = '".$trait['content_type_uuid']."'");
            $fullTraits[] = ["uuid" => $trait['content_type_uuid'], "content" => unserialize(base64_decode($fullTrait[0]["content"]))];
        }
        $data["types"] = $types;
        $data["subtypes"] = $subtypes;
        $data["traits"] = $this->filterByCategory($fullTraits, "info", "!=");
        $data["traits"] = $this->filterByCategory($data["traits"], "clan", "!=");
        dump($data);
        return $this->render('@App/form.type_restriction.html.twig', ["data" => $data]);
    }

    /**
     * @Route("/ui/character-trait/edit/{uuid}")
     * @param Request $request
     * @param string $uuid
     * @return Response
     */
    final public function UiCharacterTraitEdit(Request $request, string $uuid): Response
    {
        $db = $this->initDb();

        $baseData = $this->baseTraitData();

        $content = $db->q("SELECT content FROM content WHERE uuid = '$uuid'");
        $content = unserialize(base64_decode($content[0]['content']));

        return $this->render('@App/form.trait.html.twig', ["data" => [
            "env" => $this->getEnv($request),
            "traits" => $baseData->traits,
            "types" => $baseData->types,
            "categories" => $baseData->categories,
            "subCategories" => $baseData->subCategories,
            "org" => $baseData->traitOrg,
            "content" => $content,
            "action" => "Update",
            "route" => "/api/character-trait/edit/$uuid"
        ]]);
    }

    final private function filterByCategory($a, $category, $operation)
    {
        $o = [];
        $c = count($a);
        for ($i=0; $i<$c; $i++) {
            if (get_class($a[$i]["content"]) === "AppBundle\\Model\\Content\\CharacterTrait") {
                switch ($operation) {
                    case "==":
                        if (strtolower($a[$i]["content"]->getCategory()) === strtolower($category)) {
                            $o[] = $a[$i];
                        }
                        break;
                    case "===":
                        if ($a[$i]["content"]->getCategory() === $category) {
                            $o[] = $a[$i];
                        }
                        break;
                    case "!=":
                        if (strtolower($a[$i]["content"]->getCategory()) !== strtolower($category)) {
                            $o[] = $a[$i];
                        }
                        break;
                    case "!==":
                        if ($a[$i]["content"]->getCategory() !== $category) {
                            $o[] = $a[$i];
                        }
                        break;
                }
            } else {
                dump(get_class($a[$i]["content"]));
            }
        }
        return $o;
    }

    final private function baseTraitData()
    {
        $db = $this->initDb();
        $types = $db->q("SELECT DISTINCT value FROM index_tag WHERE content_type = 'CharacterTrait' AND field = 'type'");
        $categories = $db->q("SELECT DISTINCT value FROM index_tag WHERE content_type = 'CharacterTrait' AND field = 'category'");
        $subCategories = $db->q("SELECT DISTINCT value FROM index_tag WHERE content_type = 'CharacterTrait' AND field = 'subCategory'");
        $traits = $db->q("SELECT content_type_uuid, value FROM index_tag WHERE content_type = 'CharacterTrait' AND field = 'name'");
//        $traits = $db->rc("CharacterTrait");

        $traitOrg = [];
        $fullTraits = [];
        foreach ($traits as $trait) {
            $fullTrait = $db->q("SELECT content FROM content WHERE uuid = '".$trait['content_type_uuid']."'");
            $ft = unserialize(base64_decode($fullTrait[0]['content']));
            $fullTraits[] = $ft;
            if (empty($traitOrg[$ft->getType()])) {
                $traitOrg[$ft->getType()] = [];
            }
            if (empty($traitOrg[$ft->getType()][$ft->getCategory()])) {
                $traitOrg[$ft->getType()][$ft->getCategory()] = [];
            }
            if (empty($traitOrg[$ft->getType()][$ft->getCategory()][$ft->getSubCategory()])) {
                $traitOrg[$ft->getType()][$ft->getCategory()][$ft->getSubCategory()] = [];
            }
            $traitOrg[$ft->getType()][$ft->getCategory()][$ft->getSubCategory()][] = ["name" => $ft->getName(), 'uuid' => $trait['content_type_uuid']];
        }

        $data = new \stdClass();
        $data->types = $types;
        $data->categories = $categories;
        $data->subCategories = $subCategories;
        $data->traits = $traits;
        $data->traitOrg = $traitOrg;

        return $data;
    }

    final private function filterByUuid($a)
    {
        $d = [];
        $c = count($a);
        for ($i=0; $i<$c; $i++) {
            if (empty($d[$a[$i]["content_type_uuid"]])) {
                $d[$a[$i]["content_type_uuid"]] = [];
            }
            $d[$a[$i]["content_type_uuid"]][$a[$i]["field"]] = $a[$i];
        }
        return $d;
    }

    final private function filterByType($a, $type)
    {
        $d = [];
        foreach ($a as $k => $v) {
            if (strtolower($v["type"]["value"]) === strtolower($type)) {
                $d[$k] = $v;
            }
        }
        return $d;
    }

    final private function orderByName($a): array
    {
        $s = [];
        foreach ($a as $k => $v) {
            $s[$v['name']['value']] = $v;
        }
        $keys = array_keys($s);
        natsort($keys);
        $d = [];
        foreach ($keys as $k => $v) {
            $d[$v] = $s[$v];
        }
        return $d;
    }

    final private function initDb()
    {
        return new DB(
            $this->getParameter('database_host'),
            $this->getParameter('database_user'),
            $this->getParameter('database_password'),
            $this->getParameter('database_name')
        );
    }

    final private function dbg(): Response
    {
        return new Response("<html><head></head><body></body></html>");
    }

    /**
     * @param Request $request
     * @return string
     */
    final private function getEnv(Request $request): string
    {
        $env = "";
        if (strpos($request->getBaseUrl(), "app_dev.php") !== false) {
            $env = "/app_dev.php";
        }
        return $env;

    }
}