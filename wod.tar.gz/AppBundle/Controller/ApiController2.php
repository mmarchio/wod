<?php
namespace AppBundle\Controller;

use AppBundle\Model\System\Tag;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use AppBundle\Model\System\Content;
use AppBundle\Service\ModelDiscovery;
use AppBundle\Service\DB;
use Symfony\Component\Cache\Simple\FilesystemCache;

class ApiController2 extends Controller
{
    /**
     * @Route("/api/tag/create")
     */
    final public function ApiTagCreate(Request $request): Response
    {
        $db = $this->initDb();
        $tags = [];
        $parent = $request->request->get('parent');
        $c = count($parent);
        for ($i=0; $i<$c; $i++) {
            if (!empty($parent[$i])) {
                $parent = $parent[$i];
                break;
            }
        }
        $tag_type_uuid = $db->q("SELECT type_uuid FROM tag WHERE type = '".$request->request->get('type')."' LIMIT 1");
        $ttu = null;
        if (count($tag_type_uuid) !== 0) {
            $ttu = $tag_type_uuid[0]["type_uuid"];
        }
        $child = $request->request->get('child');
        $c = count($child);
        for ($i=0; $i<$c; $i++) {
            $tag = new Tag();
            $tag->setName($request->request->get('name'))
                ->setType($request->request->get('type'))
                ->setTypeUuid($ttu ?? $tag->genUuid())
                ->setParentUuid($parent)
                ->setChildUuid($child[$i])
                ->setUuid($tag->genUuid())
                ->setVersion(1)
                ->setState("active")
                ->setVersionSetUuid($tag->genUuid())
                ->setCreatedAt(time())
                ->setModifiedAt(time());
            $tags[] = $tag;
            if (!$ttu) {
                $ttu = $tag->getTypeUuid();
            }
        }
        $db->persistTags($tags);
        return $this->redirect($request->getBaseUrl()."/ui/tag/create");
    }

    /**
     * @Route("/api/{type}/edit/{uuid}")
     * @param Request $request
     * @param string $uuid
     * @return Response
     */
    final public function ApiContentEdit(Request $request, string $type, string $uuid): Response
    {
        $db = $this->initDb();
        $originalType = $type;
        $type = $this->prepareType($type);
        $fs = new FilesystemCache();
        $modelDiscovery = new ModelDiscovery();
        $model = $modelDiscovery->get(ucfirst($type));
        $model->hydrate($request);
        $content = $db->getContent($uuid, "content");

        /** @var Content $content */
        $content->setContent(base64_encode(serialize($model)))
            ->setModifiedAt(time())
            ->setVersion($content->getVersion() + 1)
            ->setVersionSetUuid($content->genUuid());
        $db->q("UPDATE content SET version = '{$content->getVersion()}', state= '{$content->getState()}', version_set_uuid = '{$content->getVersionSetUuid()}', modified_at = '{$content->getModifiedAt()}', content = '{$content->getContent()}' WHERE uuid = '$uuid'");
        return $this->redirect($request->getBaseUrl()."/ui/$originalType/edit/$uuid");
    }

    /**
     * @Route("/api/{type}/create")
     * @param Request $request
     * @param string $type
     * @return Response
     */
    final public function ApiContentCreate(Request $request, string $type): Response
    {
        $originalType = $type;
        $type = $this->prepareType($type);
        $fs = new FilesystemCache();
        $modelDiscovery = new ModelDiscovery();
        $model = $modelDiscovery->get(ucfirst($type));
        $model->hydrate($request);
        $content = new Content;

        $contentTypeUuid = $this->getContentTypeUuid($fs, $type, $content->genUuid());

        $content->setContentType($type)
            ->setContentTypeUuid($contentTypeUuid)
            ->setContent(base64_encode(serialize($model)))
            ->setUuid($content->genUuid())
            ->setVersion(1)
            ->setState('active')
            ->setVersionSetUuid($content->genUuid())
            ->setCreatedAt(time())
            ->setModifiedAt($content->getCreatedAt());

        $tags = $model->getTags();
        $indexTags = $model->getIndexTags();

        foreach ($indexTags as $indexTag) {
            $indexTag->setContentTypeUuid($content->getUuid());
        }

        $db = $this->initDb();
        $db->persistIndexTags($indexTags);
        $db->pc($content);
        return $this->redirect($request->getBaseUrl()."/ui/$originalType/create");
    }


    final private function getContentTypeUuid(FilesystemCache $fs, string $type, string $uuid): string
    {
        $key = "content-type-$type-uuid";
        return $this->getCache($fs, $key, $uuid);
    }

    final private function prepareType(string $type): string
    {
        $array = explode("-", $type);
        foreach ($array as &$a) {
            $a = ucfirst($a);
        }
        return implode("", $array);
    }

    final private function dbg(): Response
    {
        return new Response("<html><head></head><body></body></html>");
    }

    final private function getCache($fs, $key, $cache): string
    {
        if ($fs->has($key)) {
            $cache = $fs->get($key);
        } else {
            $fs->set($key, $cache);
        }

        return $cache;
    }

    final private function initDb()
    {
        return new DB(
            $this->getParameter('database_host'),
            $this->getParameter('database_user'),
            $this->getParameter('database_password'),
            $this->getParameter('database_name')
        );
    }
}