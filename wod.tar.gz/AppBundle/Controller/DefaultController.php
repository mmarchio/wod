<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use AppBundle\Entity\Tag;
use AppBundle\Model\Tag as TagModel;
use AppBundle\Entity\Content;
use AppBundle\Model\Traits as TraitModel;
use AppBundle\Entity\TagUnion;
use AppBundle\Model\TagUnion as TagUnionModel;
use AppBundle\Model\Content as ContentModel;
use AppBundle\Service\Validation;
use AppBundle\Model\Traits;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }

    protected function strategy(Request $request, $content)
    {
      if (!empty($content->getContent())) {
        $contentModel = unserialize($content->getContent());
      }
      switch ($content->getContentType()) {
        case "trait" :
          $tags = [
            $this->getTag($request, "name", $contentModel->getName(), $contentModel->getName(), "trait"),
            $this->getTag($request, "name", $contentModel->getPriority(), $contentModel->getPriority(), "priority")
          ];
          $c = count($tags);
          for ($i=0; $i<$c; $i++) {
            $tagUnionModel = new TagUnionModel;
            $tagUnionModel->setEntity($content->getUuid());
            $tagUnionModel->setTag($tags[$i]->getUuid());
            $tagUnionModel->setUuid($content->genUuid());
            $tagUnionModel->setState("active");
            $this->createTagUnionApi($tagUnionModel);
          }

          break;
      }
    }

    protected function getExistingTag($type)
    {
      return $this->getDoctrine()
          ->getRepository(Tag::class)
          ->findOneByType($type);
    }

    protected function getTag(Request $request, $lookup, $criteria, $name, $type)
    {
      switch ($lookup) {
          case "type":
              $tag = $this->getDoctrine()
                  ->getRepository(Tag::class)
                  ->findOneByType($criteria);
              break;
          case "name":
          $tag = $this->getDoctrine()
              ->getRepository(Tag::class)
              ->findOneByName($criteria);
              break;
      }
      if (!$tag) {
        $tagModel = new TagModel($request);
        $tagModel->setName($name);
        $tagModel->setType($type);
        $tag = $this->createTagApi($request, $tagModel);
      }
      return $tag;
    }

    /**
    * @Route("/create/tag")
    */
    public function createTagAction(Request $request)
    {
      $msg = null;
      if ($request->get("name") && $request->get("type")) {
        $msg = $this->createTagApi($request);
      }
      if (!empty($msg) && !is_string($msg)) {
        $msg = $msg->getUuid();
      }
      return $this->render('default/create.tag.html.twig', ["msg" => $msg]);
    }

    protected function base($string)
    {
      return "<!DOCTYPE><html><head></head><body>$string</body></html>";
    }

    /**
    * @Route("/create/trait")
    */
    public function createTraitAction(Request $request)
    {
      $msg = null;
      if ($request->get("name") && $request->get("type") && $request->get("category")) {
        $trait = new Traits($request);
        $trait->setContentType("trait");
        $trait->setName($request->get("name"));
        $trait->setType($request->get("type"));
        $trait->setCategory($request->get("category"));
        $msg = $this->createContentApi($request, $trait);
      }
      if (!empty($msg) && !is_string($msg)) {
        $msg = $msg->getUuid();
      }
      return $this->render('default/create.trait.html.twig', ["msg" => $msg]);
    }

    /**
    * @Route("/add/tag/{type}")
    */
    public function addTag(Request $request, $type)
    {
      if (!empty($request->get("entity")) && !empty($request->get("tag"))) {

      }
      $content = $this->getDoctrine()
          ->getRepository(Content::class)
          ->findAll();
      $tags = $this->getDoctrine()
          ->getRepository(Tag::class)
          ->findByType($type);

      $contentItems = [];
      $c = count($content);
      for ($i=0; $i<$c; $i++) {
        $temp = new \stdClass();
        $temp->uuid = $content[$i]->getUuid();
        $contentModel = unserialize($content[$i]->getContent());
        $temp->name = $contentModel->getName();
        $contentItems[] = $temp;
      }

      $tagItems = [];
      $c = count($tags);
      for ($i=0; $i<$c; $i++) {
        $temp = new \stdClass();
        $temp->uuid = $tags[$i]->getUuid();
        $temp->name = $tags[$i]->getName();
        $tagItems[] = $temp;
      }

      return $this->render('default/add.tag.html.twig',["entities" => $contentItems, "tags" => $tagItems]);

    }

    /**
    * @Route("/edit/content/{uuid}/")
    */
    public function editContent(Request $request, $uuid)
    {
        $data = $this->getEntity("content", $uuid, "simple");
        $content = $data->getContent();
        return $this->render('default/edit.html.twig', ['values' => $content, 'uuid' => $uuid]);
    }

    /**
    * @Route("/list/content")
    */
    public function listContent()
    {
        $content = $this->getDoctrine()
            ->getRepository(Content::class)
            ->findAll();

        $c = count($content);
        $items = [];
        for ($i=0; $i<$c; $i++) {
            $temp = new \stdClass();
            $temp->uuid = $content[$i]->getUuid();
            $contentModel = unserialize($content[$i]->getContent());
            $temp->name = $contentModel->getName();
            $items[] = $temp;
        }

        return $this->render('default/list.html.twig', ["items" => $items]);
    }

    protected function getEntity($type, $uuid, $rendition)
    {
      $object = null;
      $response = new Response();
      switch ($type) {
        case "content":
            $content = $this->getDoctrine()
                ->getRepository(Content::class)
                ->find($uuid);
            $tagUnion = $this->getDoctrine()
                ->getRepository(TagUnion::class)
                ->findByEntity($uuid);
            $tags = [];
            $c = count($tagUnion);
            for ($i=0; $i<$c; $i++) {
              $tag = $this->getDoctrine()
                  ->getRepository(Tag::class)
                  ->find($tagUnion[$i]->getTag());
              $temp = new \stdClass();
              $temp->uuid = $tag->getUuid();
              $temp->name = $tag->getName();
              $temp->type = $tag->getType();
              $temp->typeUuid = $tag->getTypeUuid();
              $temp->state = $tag->getState();
              $temp->version = $tag->getVersion();
              $temp->createdAt = $tag->getCreatedAt();
              $temp->modifiedAt = $tag->getModifiedAt();
              $temp->deletedAt = $tag->getDeletedAt();
              $tags[] = $temp;
            }

            $object = new \stdClass();
            $object->uuid = $content->getUuid();
            $object->state = $content->getState();
            $object->version = $content->getVersion();
            $object->createdAt = $content->getCreatedAt();
            $object->modifiedAt = $content->getModifiedAt();
            $object->deletedAt = $content->getDeletedAt();
            $object->contentType = $content->getContentType();
            $object->content = unserialize($content->getContent())->serialize();
            $object->tags = $tags;
            break;
        case "tag":
        $object = $this->getDoctrine()
            ->getRepository(Tag::class)
            ->find($uuid);
            break;

      }
      $response->setContent(json_encode($object));
      $response->headers->set("Content-Type","application/json");
      return $response;
    }


}
