<?php
namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use AppBundle\Entity\Tag;
use AppBundle\Model\Tag as TagModel;
use AppBundle\Entity\Content;
use AppBundle\Model\Traits as TraitModel;
use AppBundle\Entity\TagUnion;
use AppBundle\Model\TagUnion as TagUnionModel;
use AppBundle\Model\Content as ContentModel;
use AppBundle\Service\Validation;
use AppBundle\Model\Traits;

class ApiController extends Controller
{
  /**
  * @Route("/api/create/tag")
  */
  public function createTagApi(Request $request, $tagModel = null)
  {
      $validation = new Validation();
      $response = new Response();
      $response->setContent("action failed");
      if (!$tagModel) {
        $tagModel = new TagModel($request);
      }
      if ($validation->tag($tagModel)) {
        $tag = new Tag();
        $tag->setUuid($tag->genUuid());
        $tag->setName($tagModel->getName());
        $tag->setType($tagModel->getType());
        $existing = $this->getExistingTag($tagModel->getType());
        $tag->setTypeUuid($tagModel->getTypeUuid());
        if ($existing) {
          $tag->setTypeUuid($existing->getTypeUuid());
        }
        $tag->setCreatedAt(time());
        $tag->setModifiedAt($tag->getCreatedAt());
        $tag->setState("active");
        $tag->setVersion(1);

        $em = $this->getDoctrine()->getManager();
        $em->persist($tag);
        $em->flush();
        $response->setContent($tag->getUuid());
        return $tag;
      }
      throw new Exception("action failed");
  }

  /**
  * @Route("/api/create/content")
  */
  public function createContentApi(Request $request, $object)
  {
      $validation = new Validation();
      $contentModel = null;
      switch ($object->getContentType()) {
        case "trait":
            $contentModel = new TraitModel($request);
            $contentModel->setContentType("trait");
            break;
      }
      $msg = "";
      if ($validation->content(serialize($contentModel))) {
          $content = new Content;
          if (empty($contentModel->getUuid())) {
              $content->setUuid($content->genUuid());
          }
          if (empty($contentModel->getVersion())) {
              $content->setVersion(1);
          } else {
            $content->setVersion($contentModel->getVersion() + 1);
          }
          $content->setCreatedAt((string)$content->timestamp());
          $content->setModifiedAt($content->getCreatedAt());
          $content->setState("active");
          $content->setContent(serialize($contentModel));
          $content->setContentType($contentModel->getContentType());
          $em = $this->getDoctrine()->getManager();
          $em->persist($content);
          $em->flush();
          $this->strategy($request, $content);
          return $content;
      } else {
        dump($contentModel);
        dump($request);
        $msg = "validation failed";
      }
      throw new \Exception("action failed $msg");
  }

  /**
  * @Route("/api/create/tag-union")
  */
  public function createTagUnionApi($content)
  {
      $validation = new Validation();
      if ($validation->tagUnion($content)) {
          $union = new TagUnion;
          $union->setEntity($content->getEntity());
          $union->setTag($content->getTag());
          $union->setUuid($content->getUuid());
          $union->setState("active");
          $union->setVersion(1);
          $union->setCreatedAt((string)time());
          $union->setModifiedAt($union->getCreatedAt());
          $em = $this->getDoctrine()->getManager();
          $em->persist($union);
          $em->flush();
          return $union;
      }
      throw new \Exception("action failed");
  }

  protected function strategy(Request $request, $content)
  {
    if (!empty($content->getContent())) {
      $contentModel = unserialize($content->getContent());
    }
    switch ($content->getContentType()) {
      case "trait" :
        $tags = [
          $this->getTag($request, "name", $contentModel->getName(), $contentModel->getName(), "trait"),
          $this->getTag($request, "name", $contentModel->getPriority(), $contentModel->getPriority(), "priority")
        ];
        $c = count($tags);
        for ($i=0; $i<$c; $i++) {
          $tagUnionModel = new TagUnionModel;
          $tagUnionModel->setEntity($content->getUuid());
          $tagUnionModel->setTag($tags[$i]->getUuid());
          $tagUnionModel->setUuid($content->genUuid());
          $tagUnionModel->setState("active");
          $this->createTagUnionApi($tagUnionModel);
        }

        break;
    }
  }

  protected function getExistingTag($type)
  {
    return $this->getDoctrine()
        ->getRepository(Tag::class)
        ->findOneByType($type);
  }

  protected function getTag(Request $request, $lookup, $criteria, $name, $type)
  {
    switch ($lookup) {
        case "type":
            $tag = $this->getDoctrine()
                ->getRepository(Tag::class)
                ->findOneByType($criteria);
            break;
        case "name":
        $tag = $this->getDoctrine()
            ->getRepository(Tag::class)
            ->findOneByName($criteria);
            break;
    }
    if (!$tag) {
      $tagModel = new TagModel($request);
      $tagModel->setName($name);
      $tagModel->setType($type);
      $tag = $this->createTagApi($request, $tagModel);
    }
    return $tag;
  }

  /**
  * @Route("/api/get/{type}/{uuid}/{rendition}")
  */
  public function getEntity($type, $uuid, $rendition)
  {
    $object = null;
    $response = new Response();
    switch ($type) {
      case "content":
          $content = $this->getDoctrine()
              ->getRepository(Content::class)
              ->find($uuid);
          $tagUnion = $this->getDoctrine()
              ->getRepository(TagUnion::class)
              ->findByEntity($uuid);
          $tags = [];
          $c = count($tagUnion);
          for ($i=0; $i<$c; $i++) {
            $tag = $this->getDoctrine()
                ->getRepository(Tag::class)
                ->find($tagUnion[$i]->getTag());
            $temp = new \stdClass();
            $temp->uuid = $tag->getUuid();
            $temp->name = $tag->getName();
            $temp->type = $tag->getType();
            $temp->typeUuid = $tag->getTypeUuid();
            $temp->state = $tag->getState();
            $temp->version = $tag->getVersion();
            $temp->createdAt = $tag->getCreatedAt();
            $temp->modifiedAt = $tag->getModifiedAt();
            $temp->deletedAt = $tag->getDeletedAt();
            $tags[] = $temp;
          }

          $object = new \stdClass();
          $object->uuid = $content->getUuid();
          $object->state = $content->getState();
          $object->version = $content->getVersion();
          $object->createdAt = $content->getCreatedAt();
          $object->modifiedAt = $content->getModifiedAt();
          $object->deletedAt = $content->getDeletedAt();
          $object->contentType = $content->getContentType();
          $object->content = unserialize($content->getContent())->serialize();
          $object->tags = $tags;
          break;
      case "tag":
      $object = $this->getDoctrine()
          ->getRepository(Tag::class)
          ->find($uuid);
          break;

    }
    $response->setContent(json_encode($object));
    $response->headers->set("Content-Type","application/json");
    return $response;
  }

  /**
  * @Route("/api/edit/content")
  */
  public function editContentApi(Request $request)
  {
    $msg = '{"msg":"no changes"}';
    $data = $request->getContent();
    dump($data);
    $content = new ContentModel;
    $content->mergeJson($data);
    dump($content);

    $existing = $this->getDoctrine()
        ->getRepository(Content::class)
        ->find($content->getUuid());
    $newContent = unserialize($content->getContent());
    $existingContent = unserialize($existing->getContent());

    $properties = $newContent->getProperties();
    $c = count($properties);
    $change = false;
    for ($i=0; $i<$c; $i++) {
      $property = $properties[$i];
      $underscores = explode("_", $property->get);
      if (!empty($underscores[1])) {
        $property->get = $underscores[0].ucfirst($underscores[1]);
      }
      if ($newContent->{$property->get}() !== $existingContent->{$property->get}()) {
          $change = true;
      }
    }
    if ($change === true) {
      $em = $this->getDoctrine()->getManager();
      $existing->setContent(serialize($newContent));
      $existing->setModifiedAt((string)time());
      $em->persist($existing);
      $em->flush();
      $msg = '{"msg":"'.$existing->getUuid().'"}';
    }
    dump($newContent);
    dump($existingContent);
    // $tags = $data->tags;
    return new Response($msg);
  }
}
