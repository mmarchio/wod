<?php
namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use AppBundle\Entity\Tag;
use AppBundle\Model\Tag as TagModel;
use AppBundle\Entity\Content;
use AppBundle\Model\Traits as TraitModel;
use AppBundle\Entity\TagUnion;
use AppBundle\Model\TagUnion as TagUnionModel;
use AppBundle\Service\Validation;
use AppBundle\Model\Traits;

class ContentController extends Controller
{

}
