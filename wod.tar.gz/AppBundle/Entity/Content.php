<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Content
 *
 * @ORM\Table(name="content")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\ContentRepository")
 */
class Content extends Entity
{
    /**
     * @var string
     *
     * @ORM\Column(name="uuid", type="string", length=36)
     * @ORM\Id
     */
    private $uuid;

    /**
     * @var string
     *
     * @ORM\Column(name="state", type="string", length=255)
     */
    private $state;

    /**
     * @var int
     *
     * @ORM\Column(name="version", type="integer")
     */
    private $version;

    /**
     * @var string
     *
     * @ORM\Column(name="created_at", type="string", length=255)
     */
    private $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="modified_at", type="string", length=255)
     */
    private $modifiedAt;

    /**
     * @var string
     *
     * @ORM\Column(name="deleted_at", type="string", length=255)
     */
    private $deletedAt;

    /**
    * @var string
    *
    * @ORM\Column(name="content_type", type="string", length=255)
    */
    private $contentType;

    /**
     * @var string
     *
     * @ORM\Column(name="content", type="text")
     */
    private $content;



    /**
    *
    * @param string $uuid
    *
    * @return Content
    */
    public function setUuid(?string $uuid = null)
    {
        if (empty($uuid)) {
          $uuid = $this->genUuid();
        }
        $this->uuid = $uuid;
        return $this;
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getUuid()
    {
        return $this->uuid;
    }

    /**
     * Set state
     *
     * @param string $state
     *
     * @return Content
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set version
     *
     * @param integer $version
     *
     * @return Content
     */
    public function setVersion($version)
    {
        $this->version = $version;

        return $this;
    }

    /**
     * Get version
     *
     * @return int
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     *
     * @return Content
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set modifiedAt
     *
     * @param string $modifiedAt
     *
     * @return Content
     */
    public function setModifiedAt($modifiedAt)
    {
        $this->modifiedAt = $modifiedAt;

        return $this;
    }

    /**
     * Get modifiedAt
     *
     * @return string
     */
    public function getModifiedAt()
    {
        return $this->modifiedAt;
    }

    /**
     * Set deletedAt
     *
     * @param string $deletedAt
     *
     * @return Content
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return string
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return Content
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
    * Set contentType
    *
    * @param string $contentType
    *
    * @return Content
    */
    public function setContentType($contentType)
    {
      $this->contentType = $contentType;

      return $this;
    }

    /**
    * Get contentType
    *
    * @return string
    */
    public function getContentType()
    {
        return $this->contentType;
    }

    public function getFormValues()
    {
      $values = [];
      foreach ($this as $k => $v) {
        $temp = new \stdClass();
        $temp->key = $k;
        $temp->value = $v;
        $values = [];
      }
      return $values;
    }
}
