<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * tag
 *
 * @ORM\Table(name="tags")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\TagRepository")
 */
class Tag extends Entity
{
    /**
     * @var string
     *
     * @ORM\Column(name="uuid", type="string")
     * @ORM\Id
     */
    private $uuid;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=36)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="type_uuid", type="string", length=255)
     */
    private $typeUuid;

    /**
     * @var string
     *
     * @ORM\Column(name="state", type="string", length=255)
     */
    private $state;

    /**
     * @var int
     *
     * @ORM\Column(name="version", type="integer")
     */
    private $version;

    /**
     * @var string
     *
     * @ORM\Column(name="created_at", type="string", length=36)
     */
    private $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="modified_at", type="string", length=36)
     */
    private $modifiedAt;

    /**
     * @var string
     *
     * @ORM\Column(name="deleted_at", type="string", length=36)
     */
    private $deletedAt;

    /**
     * Set state
     *
     * @param string $state
     *
     * @return Tag
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set version
     *
     * @param integer $version
     *
     * @return Tag
     */
    public function setVersion($version = 1)
    {
        $this->version = $version;

        return $this;
    }

    /**
     * Get version
     *
     * @return int
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     *
     * @return Tag
     */
    public function setCreatedAt(?string $createdAt = null)
    {
        if (empty($createdAt)) {
            $createdAt = date("Y-m-d h:i:s",time());
        }
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set modifiedAt
     *
     * @param string $modifiedAt
     *
     * @return Tag
     */
    public function setModifiedAt(?string $modifiedAt = null)
    {
        if (empty($modifiedAt)) {
            $modifiedAt = date("Y-m-d h:i:s",time());
        }
        $this->modifiedAt = $modifiedAt;

        return $this;
    }

    /**
     * Get modifiedAt
     *
     * @return string
     */
    public function getModifiedAt()
    {
        return $this->modifiedAt;
    }

    /**
     * Set deletedAt
     *
     * @param string $deletedAt
     *
     * @return Tag
     */
    public function setDeletedAt(?string $deletedAt = null)
    {
        if (empty($deletedAt)) {
            $deletedAt = date("Y-m-d h:i:s");
        }
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return string
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }


    /**
    *
    * @param string $uuid
    *
    * @return Tag
    */
    public function setUuid(?string $uuid = null)
    {
        if (empty($uuid)) {
            $uuid = $this->genUuid();
        }
        $this->uuid = $uuid;
        return $this;
    }

    /**
     * Get uuid
     *
     * @return string
     */
    public function getUuid()
    {
        return $this->uuid;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Tag
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return Tag
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set typeUuid
     *
     * @param string $typeUuid
     *
     * @return Tag
     */
    public function setTypeUuid(?string $typeUuid = null)
    {
        if (empty($typeUuid)) {
          $typeUuid = $this->genUuid();
        }
        $this->typeUuid = $typeUuid;

        return $this;
    }

    /**
     * Get typeUuid
     *
     * @return string
     */
    public function getTypeUuid()
    {
        return $this->typeUuid;
    }
}
