<?php
namespace AppBundle\Model\Content;

use AppBundle\Model\ContentBase;
use Symfony\Component\HttpFoundation\Request;

class CharacterTrait extends ContentBase
{
    protected $name;
    protected $type;
    protected $category;
    protected $subCategory;

    /**
     * @return string
     */
    final public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     * @return CharacterTrait
     */
    final public function setName(string $name): CharacterTrait
    {
        $this->name = $name;
        $this->appendIndexTags(
            $this->createIndexTag(
            "CharacterTrait",
            "name",
            $this->name
        ));
        return $this;
    }

    /**
     * @return string
     */
    final public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return CharacterTrait
     */
    final public function setType(string $type): CharacterTrait
    {
        $this->type = $type;
        $this->appendIndexTags(
            $this->createIndexTag(
            "CharacterTrait",
            "type",
            $this->type
        ));
        return $this;
    }

    /**
     * @return string
     */
    final public function getCategory(): string
    {
        return $this->category;
    }

    /**
     * @param string $category
     * @return CharacterTrait
     */
    final public function setCategory(string $category): CharacterTrait
    {
        $this->category = $category;
        $this->appendIndexTags(
            $this->createIndexTag(
                "CharacterTrait",
                "category",
                $this->category
        ));
        return $this;
    }

    /**
     * @return string
     */
    final public function getSubCategory(): string
    {
        return $this->subCategory;
    }

    /**
     * @param string $subCategory
     * @return CharacterTrait
     */
    final public function setSubCategory(string $subCategory): CharacterTrait
    {
        $this->subCategory = $subCategory;
        $this->appendIndexTags(
            $this->createIndexTag(
                "CharacterTrait",
                "subCategory",
                $this->subCategory
        ));
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        dump($request);
        $this->setName($request->request->get("name"))
            ->setType($request->request->get("type"))
            ->setCategory($request->request->get('category'))
            ->setSubCategory($request->request->get("sub-category"));
    }

}