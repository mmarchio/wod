<?php
namespace AppBundle\Model\Content;

use Symfony\Component\HttpFoundation\Request;

class Chronicle
{
    private $name;

    /**
     * @return string
     */
    final public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     * @return Chronicle
     */
    final public function setName(string $name): Chronicle
    {
        $this->name = $name;
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        $this->setName($request->get('name'));
    }
}