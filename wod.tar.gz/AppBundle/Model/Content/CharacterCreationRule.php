<?php
namespace AppBundle\Model\Content;

use AppBundle\Model\ContentBase;
use Symfony\Component\HttpFoundation\Request;

class CharacterCreationRule extends ContentBase
{
    protected $name;
    protected $type;
    protected $rank;
    protected $rankLevel;
    protected $attributePrimary;
    protected $attributeSecondary;
    protected $attributeTertiary;
    protected $abilityPrimary;
    protected $abilitySecondary;
    protected $abilityTertiary;
    protected $special;
    protected $backgrounds;
    protected $virtues;
    protected $factions;

    /**
     * @return string
     */
    final public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     * @return CharacterCreationRule
     */
    final public function setName(string $name): CharacterCreationRule
    {
        $this->name = $name;
        $this->appendIndexTags(
            $this->createIndexTag(
                "CharacterCreationRule",
                "name",
                $this->name
            ));
        return $this;
    }

    /**
     * @return string
     */
    final public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return CharacterCreationRule
     */
    final public function setType(string $type): CharacterCreationRule
    {
        $this->type = $type;
        $this->appendIndexTags(
            $this->createIndexTag(
                "CharacterCreationRule",
                "type",
                $this->type
            ));
        return $this;
    }

    /**
     * @return string
     */
    final public function getRank(): string
    {
        return $this->rank;
    }

    /**
     * @param string $rank
     * @return CharacterCreationRule
     */
    final public function setRank(string $rank): CharacterCreationRule
    {
        $this->rank = $rank;
        $this->appendIndexTags(
            $this->createIndexTag(
                "CharacterCreationRule",
                "rank",
                $this->rank
            ));
        return $this;
    }

    /**
     * @return int
     */
    final public function getRankLevel(): int
    {
        return $this->rankLevel;
    }

    /**
     * @param int $rankLevel
     * @return CharacterCreationRule
     */
    final public function setRankLevel(int $rankLevel): CharacterCreationRule
    {
        $this->rankLevel = $rankLevel;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAttributePrimary(): int
    {
        return $this->attributePrimary;
    }

    /**
     * @param int $attributePrimary
     * @return CharacterCreationRule
     */
    final public function setAttributePrimary(int $attributePrimary): CharacterCreationRule
    {
        $this->attributePrimary = $attributePrimary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAttributeSecondary(): int
    {
        return $this->attributeSecondary;
    }

    /**
     * @param int $attributeSecondary
     * @return CharacterCreationRule
     */
    final public function setAttributeSecondary(int $attributeSecondary): CharacterCreationRule
    {
        $this->attributeSecondary = $attributeSecondary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAttributeTertiary(): int
    {
        return $this->attributeTertiary;
    }

    /**
     * @param int $attributeTertiary
     * @return CharacterCreationRule
     */
    final public function setAttributeTertiary(int $attributeTertiary): CharacterCreationRule
    {
        $this->attributeTertiary = $attributeTertiary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAbilityPrimary(): int
    {
        return $this->abilityPrimary;
    }

    /**
     * @param int $abilityPrimary
     * @return CharacterCreationRule
     */
    final public function setAbilityPrimary(int $abilityPrimary): CharacterCreationRule
    {
        $this->abilityPrimary = $abilityPrimary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAbilitySecondary(): int
    {
        return $this->abilitySecondary;
    }

    /**
     * @param int $abilitySecondary
     * @return CharacterCreationRule
     */
    final public function setAbilitySecondary(int $abilitySecondary): CharacterCreationRule
    {
        $this->abilitySecondary = $abilitySecondary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAbilityTertiary(): int
    {
        return $this->abilityTertiary;
    }

    /**
     * @param int $abilityTertiary
     * @return CharacterCreationRule
     */
    final public function setAbilityTertiary(int $abilityTertiary): CharacterCreationRule
    {
        $this->abilityTertiary = $abilityTertiary;
        return $this;
    }

    /**
     * @return int
     */
    final public function getSpecial(): int
    {
        return $this->special;
    }

    /**
     * @param int $special
     * @return CharacterCreationRule
     */
    final public function setSpecial(int $special): CharacterCreationRule
    {
        $this->special = $special;
        return $this;
    }

    /**
     * @return int
     */
    final public function getBackgrounds(): int
    {
        return $this->backgrounds;
    }

    /**
     * @param int $backgrounds
     * @return CharacterCreationRule
     */
    final public function setBackgrounds(int $backgrounds): CharacterCreationRule
    {
        $this->backgrounds = $backgrounds;
        return $this;
    }

    /**
     * @return int
     */
    final public function getVirtues(): int
    {
        return $this->virtues;
    }

    /**
     * @param int $virtues
     * @return CharacterCreationRule
     */
    final public function setVirtues(int $virtues): CharacterCreationRule
    {
        $this->virtues = $virtues;
        return $this;
    }

    /**
     * @return array
     */
    final public function getFactions(): array
    {
        return $this->factions;
    }

    /**
     * @param array $factions
     * @return CharacterCreationRule
     */
    final public function setFactions(array $factions): CharacterCreationRule
    {
        $this->factions = $factions;
        return $this;
    }

    /**
     * @param string $faction
     * @return CharacterCreationRule
     */
    final public function appendFactions(string $faction): CharacterCreationRule
    {
        if (!is_array($this->factions)) {
            $this->factions = [];
        }
        $this->factions[] = $faction;
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        $r = $request->request;
        $this->setName($r->get('name'))
            ->setType($r->get('type'))
            ->setRank($r->get('rank'))
            ->setRankLevel($r->get('rankLevel'))
            ->setAttributePrimary($r->get('attributePrimary'))
            ->setAttributeSecondary($r->get('attributeSecondary'))
            ->setAttributeTertiary($r->get('attributeTertiary'))
            ->setAbilityPrimary($r->get('abilityPrimary'))
            ->setAbilitySecondary($r->get('abilitySecondary'))
            ->setAbilityTertiary($r->get('abilityTertiary'))
            ->setSpecial($r->get('special'))
            ->setBackgrounds($r->get('backgrounds'))
            ->setVirtues($r->get('virtues'))
            ->setFactions($r->get('factions'));
    }
}