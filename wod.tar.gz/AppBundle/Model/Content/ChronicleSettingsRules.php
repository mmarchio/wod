<?php
namespace AppBundle\Model\Content;

use Symfony\Component\HttpFoundation\Request;

class ChronicleSettingsRules
{
    private $creation;
    private $rolls;

    /**
     * @return array
     */
    final public function getCreation(): array
    {
        return $this->creation;
    }

    /**
     * @param array $creation
     * @return ChronicleSettingsRules
     */
    final public function setCreation(array $creation): ChronicleSettingsRules
    {
        $this->creation = $creation;
        return $this;
    }

    /**
     * @return array
     */
    final public function getRolls(): array
    {
        return $this->rolls;
    }

    /**
     * @param array $rolls
     * @return ChronicleSettingsRules
     */
    final public function setRolls(array $rolls): ChronicleSettingsRules
    {
        $this->rolls = $rolls;
        return $this;
    }
}