<?php
namespace AppBundle\Model\Content;

use Symfony\Component\HttpFoundation\Request;

class ChronicleSettingsRulesCreation
{
    private $type;
    private $rank;
    private $attributes;
    private $abilities;
    private $special;
    private $backgrounds;
    private $virtues;
    private $restrictions;

    /**
     * @return string
     */
    final public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return ChronicleSettingsRulesCreation
     */
    final public function setType(string $type): ChronicleSettingsRulesCreation
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @return string
     */
    final public function getRank(): string
    {
        return $this->rank;
    }

    /**
     * @param string $rank
     * @return ChronicleSettingsRulesCreation
     */
    final public function setRank(string $rank): ChronicleSettingsRulesCreation
    {
        $this->rank = $rank;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAttributes(): int
    {
        return $this->attributes;
    }

    /**
     * @param int $attributes
     * @return ChronicleSettingsRulesCreation
     */
    final public function setAttributes(int $attributes): ChronicleSettingsRulesCreation
    {
        $this->attributes = $attributes;
        return $this;
    }

    /**
     * @return int
     */
    final public function getAbilities(): int
    {
        return $this->abilities;
    }

    /**
     * @param int $abilities
     * @return ChronicleSettingsRulesCreation
     */
    final public function setAbilities(int $abilities): ChronicleSettingsRulesCreation
    {
        $this->abilities = $abilities;
    }

    /**
     * @return int
     */
    final public function getSpecial(): int
    {
        return $this->special;
    }

    /**
     * @param int $special
     * @return ChronicleSettingsRulesCreation
     */
    final public function setSpecial(int $special): ChronicleSettingsRulesCreation
    {
        $this->special = $special;
    }

    /**
     * @return int
     */
    final public function getBackgrounds(): int
    {
        return $this->backgrounds;
    }

    /**
     * @param int $backgrounds
     * @return ChronicleSettingsRulesCreation
     */
    final public function setBackgrounds(int $backgrounds): ChronicleSettingsRulesCreation
    {
        $this->backgrounds = $backgrounds;
        return $this;
    }

    /**
     * @return int
     */
    final public function getVirtues(): int
    {
        return $this->virtues;
    }

    /**
     * @param int $virtues
     * @return ChronicleSettingsRulesCreation
     */
    final public function setVirtues(int $virtues): ChronicleSettingsRulesCreation
    {
        $this->virtues = $virtues;
        return $this;
    }

    /**
     * @return array
     */
    final public function getRestrictions(): array
    {
        return $this->restrictions;
    }

    /**
     * @param array $restrictions
     * @return ChronicleSettingsRulesCreation
     */
    final public function setRestrictions(array $restrictions): ChronicleSettingsRulesCreation
    {
        $this->restrictions = $restrictions;
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        $this->setType($request->get('type'))
            ->setRank($request->get('rank'))
            ->setAttributes($request->get('attributes'))
            ->setAbilities($request->get('abilities'))
            ->setSpecial($request->get('special'))
            ->setBackgrounds($request->get('backgrounds'))
            ->setVirtues($request->get('virtues'));
    }
    
}