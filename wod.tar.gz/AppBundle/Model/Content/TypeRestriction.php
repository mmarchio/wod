<?php
namespace AppBundle\Model\Content;

use AppBundle\Model\ContentBase;
use Symfony\Component\HttpFoundation\Request;

class TypeRestriction extends ContentBase
{
    protected $type;
    protected $subtype;
    protected $restriction;
    protected $maxValue;

    /**
     * @return string
     */
    final public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return TypeRestriction
     */
    final public function setType(string $type): TypeRestriction
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @return string
     */
    final public function getSubtype(): string
    {
        return $this->subtype;
    }

    /**
     * @param string $subtype
     * @return TypeRestriction
     */
    final public function setSubtype(string $subtype): TypeRestriction
    {
        $this->subtype = $subtype;
        return $this;
    }

    /**
     * @return string
     */
    final public function getRestriction(): string
    {
        return $this->restriction;
    }

    /**
     * @param string $restriction
     * @return TypeRestriction
     */
    final public function setRestriction(string $restriction): TypeRestriction
    {
        $this->restriction = $restriction;
        return $this;
    }

    /**
     * @return int
     */
    final public function getMaxValue(): int
    {
        return $this->maxValue;
    }

    /**
     * @param int $maxValue
     * @return TypeRestriction
     */
    final public function setMaxValue(int $maxValue): TypeRestriction
    {
        $this->maxValue = $maxValue;
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        $r = $request->request;
        $this->setType($r->get('type'))
            ->setSubtype($r->get('subtype'))
            ->setRestriction($r->get('restriction'))
            ->setMaxValue($r->get('maxValue'));
    }
}