<?php
namespace AppBundle\Model\Content;

use Symfony\Component\HttpFoundation\Request;

class ChronicleSettings
{
    private $startDate;
    private $locales;
    private $rules;

    /**
     * @return string
     */
    final public function getStartDate(): string
    {
        return $this->startDate;
    }

    /**
     * @param string $startDate
     * @return ChronicleSettings
     */
    final public function setStartDate($startDate): ChronicleSettings
    {
        $this->startDate = $startDate;
        return $this;
    }

    /**
     * @return array
     */
    final public function getLocales(): array
    {
        return $this->locales;
    }

    /**
     * @param array $locales
     * @return ChronicleSettings
     */
    final public function setLocales(array $locales): ChronicleSettings
    {
        $this->locales = $locales;
        return $this;
    }

    /**
     * @return array
     */
    final public function getRules(): array
    {
        return $this->rules;
    }

    /**
     * @param array $rules
     * @return ChronicleSettings
     */
    final public function setRules(array $rules): ChronicleSettings
    {
        $this->rules = $rules;
        return $this;
    }

    final public function hydrate(Request $request): void
    {
        $this->setStartDate($request->get("startDate"));
    }
}