<?php
namespace AppBundle\Model;

use AppBundle\Model\System\Tag;
use AppBundle\Model\System\IndexTag;

class Common
{
  protected $uuid;
  protected $state;
  protected $version;
  protected $versionSetUuid;
  protected $createdAt;
  protected $modifiedAt;
  protected $deleted_at;
  protected $tags;
  protected $indexTags;

  public function genUuid()
  {
    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
        mt_rand( 0, 0xffff ),
        mt_rand( 0, 0x0fff ) | 0x4000,
        mt_rand( 0, 0x3fff ) | 0x8000,
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ));
  }

  public function setUuid(?string $uuid = null)
  {
    if (!$uuid) {
      $uuid = $this->genUuid();
    }
    $this->uuid = $uuid;
    return $this;
  }

  public function getUuid()
  {
    return $this->uuid;
  }

  public function setState(string $state)
  {
    $this->state = $state;
    return $this;
  }

  public function getState()
  {
    return $this->state;
  }

  public function setVersion(int $version)
  {
    $this->version = $version;
    return $this;
  }

  public function getVersion()
  {
    return $this->version;
  }

  /**
   * @return string
   */
  public function getVersionSetUuid(): string
  {
      return $this->versionSetUuid;
  }

  /**
   * @param string $versionSetUuid
   * @return Common
   */
  public function setVersionSetUuid($versionSetUuid)
  {
      $this->versionSetUuid = $versionSetUuid;
      return $this;
  }

  public function setCreatedAt($createdAt)
  {
      if (!is_object($createdAt)) {
          $dt = new \DateTime;
          $createdAt = $dt->setTimestamp((int)$createdAt)->format("Y-m-d H:i:s");
      }
    $this->createdAt = $createdAt;
    return $this;
  }

  public function getCreatedAt()
  {
    return $this->createdAt;
  }

  public function setModifiedAt($modifiedAt)
  {
      if (!is_object($modifiedAt)){
          $dt = new \DateTime;
          $modifiedAt = $dt->setTimestamp((int)$modifiedAt)->format("Y-m-d H:i:s");
      }
    $this->modifiedAt = $modifiedAt;
    return $this;
  }

  public function getModifiedAt()
  {
    return $this->modifiedAt;
  }

  public function setDeletedAt($deletedAt)
  {
    $this->deleted_at = $deletedAt;
    return $this;
  }

  public function getDeletedAt()
  {
    return $this->deleted_at;
  }

  public function getFormValues()
  {
    $values = [];
    foreach ($this as $k => $v) {
      $temp = new \stdClass();
      $temp->key = $k;
      $temp->value = $v;
      $values = [];
    }
    return $values;
  }

  public function serialize()
  {
    $object = new \stdClass();
    foreach ($this as $k => $v) {
      $object->{$k} = $v;
    }
    return $object;
  }

  public function getProperties()
  {
    $properties = [];
    foreach ($this as $k => $v) {
      $temp = new \stdClass();
      $temp->get = "get".ucfirst($k);
      $temp->set = "set".ucfirst($k);
      $temp->name = $k;
      $properties[] = $temp;
    }
    return $properties;
  }

  public function getTags(): array
  {
      return $this->tags;
  }

  public function setTags(array $tags)
  {
      $this->tags = $tags;
      return $this;
  }

  public function appendTags(Tag $tag)
  {
      if (!is_array($this->tags)) {
          $this->tags = [];
      }
      $this->tags[] = $tag;
      return $this;
  }

  public function getIndexTags(): array
  {
      return $this->indexTags;
  }

  public function setIndexTags(array $indexTags)
  {
      $this->indexTags = $indexTags;
      return $this;
  }

  public function appendIndexTags(IndexTag $indexTag)
  {
      if (!is_array($this->indexTags)) {
          $this->indexTags = [];
      }
      $this->indexTags[] = $indexTag;
      return $this;
  }
}
