<?php
namespace AppBundle\Model;

class TagUnion extends Common
{
  protected $entity;
  protected $tag;

  public function setEntity(string $entity)
  {
    $this->entity = $entity;
    return $this;
  }

  public function getEntity()
  {
    return $this->entity;
  }

  public function setTag(string $tag)
  {
    $this->tag = $tag;
    return $this;
  }

  public function getTag()
  {
    return $this->tag;
  }
}
