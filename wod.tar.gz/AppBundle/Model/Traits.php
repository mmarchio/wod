<?php
namespace AppBundle\Model;

use Symfony\Component\HttpFoundation\Request;

class Traits extends Content
{
  protected $name;
  protected $type;
  protected $category;
  protected $priority;

  public function __construct(?Request $request = null)
  {
      if (!empty($request)) {
        $this->setName($request->get("name"));
        $this->setType($request->get("type"));
        $this->setCategory($request->get("category"));
        $this->setPriority($request->get("priority"));
      }
  }

  public function hydrate($object)
  {
      if (!empty($object->name)) {
        $this->setName($object->name);
      }
      if (!empty($object->type)) {
        $this->setType($object->type);
      }
      if (!empty($object->category)) {
        $this->setCategory($object->category);
      }
      if (!empty($object->priority)) {
        $this->setPriority($object->priority);
      }
      if (!empty($object->uuid)) {
        $this->setUuid($object->uuid);
      }
      if (!empty($object->state)) {
        $this->setState($object->state);
      }
      if (!empty($object->version)) {
        $this->setVersion($object->version);
      }
      if (!empty($object->createdAt)) {
        $this->setCreatedAt($object->createdAt);
      }
      if (!empty($object->modifiedAt)) {
        $this->setModifiedAt($object->modifiedAt);
      }
      if (!empty($object->deletedAt)) {
        $this->setDeletedAt($object->deletedAt);
      }
      if (!empty($object->contentType)) {
        $this->setContentType($object->contentType);
      }
  }

  public function setName($name)
  {
    $this->name = $name;
    return $this;
  }

  public function getName()
  {
    return $this->name;
  }

  public function setType($type)
  {
    $this->type = $type;
    return $this;
  }

  public function getType()
  {
    return $this->type;
  }

  public function setCategory($category)
  {
    $this->category = $category;
    return $this;
  }

  public function getCategory()
  {
    return $this->category;
  }

  public function setPriority($priority)
  {
    $this->priority = $priority;
    return $this;
  }

  public function getPriority()
  {
    return $this->priority;
  }
}
