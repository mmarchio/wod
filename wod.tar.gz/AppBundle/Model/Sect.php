<?php
namespace AppBundle\Model;

class Sect extends Common
{
  protected $name;

  public function hydrate($object)
  {
    if (!empty($object->name)) {
      $this->setName($object->name);
    }
    if (!empty($object->uuid)) {
      $this->setUuid($object->uuid);
    }
    if (!empty($object->state)) {
      $this->setState($object->state);
    }
    if (!empty($object->version)) {
      $this->setVersion($object->version);
    }
    if (!empty($object->createdAt)) {
      $this->setCreatedAt($object->createdAt);
    }
    if (!empty($object->modifiedAt)) {
      $this->setModifiedAt($object->modifiedAt);
    }
    if (!empty($object->deletedAt)) {
      $this->setDeletedAt($object->deletedAt);
    }
    if (!empty($object->contentType)) {
      $this->setContentType($object->contentType);
    }
  }

  public function setName($name)
  {
    $this->name = $name;
    return $this;
  }

  public function getName()
  {
    return $this->name;
  }
}
