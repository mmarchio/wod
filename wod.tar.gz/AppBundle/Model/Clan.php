<?php
namespace AppBundle\Model;

class Clan extends Common
{
    protected $name;
    protected $description;
    protected $disciplines;
    protected $weakness;

    public function hydrate($object)
    {
      if (!empty($object->name)) {
        $this->setName($object->name);
      }
      if (!empty($object->description)) {
        $this->setDescription($object->description);
      }
      if (!empty($object->disciplines)) {
        $this->setDisciplines($object->disciplines);
      }
      if (!empty($object->weakness)) {
        $this->setWeakness($object->weakness);
      }
      if (!empty($object->uuid)) {
        $this->setUuid($object->uuid);
      }
      if (!empty($object->state)) {
        $this->setState($object->state);
      }
      if (!empty($object->version)) {
        $this->setVersion($object->version);
      }
      if (!empty($object->createdAt)) {
        $this->setCreatedAt($object->createdAt);
      }
      if (!empty($object->modifiedAt)) {
        $this->setModifiedAt($object->modifiedAt);
      }
      if (!empty($object->deletedAt)) {
        $this->setDeletedAt($object->deletedAt);
      }
      if (!empty($object->contentType)) {
        $this->setContentType($object->contentType);
      }
    }

    public function setName($name)
    {
      $this->name = $name;
      return $this;
    }

    public function getName()
    {
      return $this->name;
    }

    public function setDescription($description)
    {
      $this->description = $descripton;
      return $this;
    }

    public function getDescription()
    {
      return $this->description;
    }

    public function setDisciplines($disciplines)
    {
      $this->disciplines = $disciplines;
      return $this;
    }

    public function getDisciplines()
    {
      return $this->disciplines;
    }

    public function setWeakness($weakness)
    {
      $this->weakness = $weakness;
      return $this;
    }

    public function getWeakness()
    {
      return $this->weakness;
    }
}
