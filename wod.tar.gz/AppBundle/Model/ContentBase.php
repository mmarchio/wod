<?php
namespace AppBundle\Model;

use AppBundle\Model\System\Tag;
use AppBundle\Model\System\IndexTag;
use AppBundle\Model\System\Content;
use Symfony\Component\Cache\Simple\FilesystemCache;

class ContentBase
{
    protected $tags;
    protected $indexTags;

    /**
     * @return array
     */
    final public function getTags(): ?array
    {
        return $this->tags;
    }

    /**
     * @param array $tags
     */
    final public function setTags(array $tags): void
    {
        $this->tags = $tags;
    }

    /**
     * @param Tag $tag
     */
    final public function appendTags(Tag $tag): void
    {
        if (!is_array($this->tags)) {
            $this->tags = [];
        }
        $this->tags[] = $tag;
    }

    /**
     * @return array
     */
    final public function getIndexTags(): ?array
    {
        return $this->indexTags;
    }

    /**
     * @param array $indexTags
     */
    final public function setIndexTags(array $indexTags): void
    {
        $this->indexTags = $indexTags;
    }

    /**
     * @param IndexTag $indexTag
     */
    final public function appendIndexTags(IndexTag $indexTag): void
    {
        if (!is_array($this->indexTags)) {
            $this->indexTags = [];
        }
        $this->indexTags[] = $indexTag;
    }

    public function createTag(string $name, string $type, string $parent, ?string $child): Tag
    {
        $key = "tag-type-uuid-$type";

        $tag = new Tag;
        $tag->setName($name)
            ->setType($type)
            ->setTypeUuid($this->getCache($key, $tag->genUuid()))
            ->setParentUuid($parent)
            ->setVersion(1)
            ->setState("active")
            ->setVersionSetUuid($tag->genUuid())
            ->setCreatedAt(time())
            ->setModifiedAt(time())
            ->setUuid($tag->genUuid());
        if ($child) {
            $tag->setChildUuid($child);
        }

        return $tag;
    }

    public function createIndexTag(string $contentType, string $field, $value): IndexTag
    {
        $key = "index-tag-content-type-uuid-$contentType";

        $indexTag = new IndexTag();
        $indexTag->setContentType($contentType)
            ->setField($field)
            ->setValue($value)
            ->setUuid($indexTag->genUuid())
            ->setVersion(1)
            ->setState("active")
            ->setVersionSetUuid($indexTag->genUuid())
            ->setCreatedAt(time())
            ->setModifiedAt(time());

        return $indexTag;
    }

    private function getCache($key, $uuid): string
    {
        $cache = null;
        $fs = new FilesystemCache();
        if ($fs->has($key)) {
            $cache = $fs->get($key);
        } else {
            $cache = $uuid;
            $fs->set($key, $cache);
        }

        return $cache;
    }
}