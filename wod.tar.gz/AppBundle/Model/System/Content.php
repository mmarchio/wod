<?php
namespace AppBundle\Model\System;

use AppBundle\Service\ModelDiscovery;
use AppBundle\Model\Common;

class Content extends Common
{
  protected $content;
  protected $contentType;
  protected $contentTypeUuid;

  public function setContentType($contentType)
  {
    $this->contentType = ucfirst($contentType);
    return $this;
  }

  public function getContentType()
  {
    return $this->contentType;
  }

    /**
     * @return string
     */
    final public function getContentTypeUuid(): string
    {
        return $this->contentTypeUuid;
    }

    /**
     * @param string $contentTypeUuid
     * @return Content
     */
    final public function setContentTypeUuid(string $contentTypeUuid): Content
    {
        $this->contentTypeUuid = $contentTypeUuid;
        return $this;
    }



  public function setContent($content)
  {
    $this->content = $content;
    return $this;
  }

  public function getContent()
  {
    return $this->content;
  }

  public function mergeJson(string $string)
  {
    $data = json_decode($string);
    if (!empty($data)) {
      $this->setUuid($data->uuid);
      $this->setState($data->state);
      $this->setVersion($data->version);
      $this->setCreatedAt($data->createdAt);
      $this->setModifiedAt($data->modifiedAt);
      $this->setDeletedAt($data->deletedAt);
      $this->setContentType($data->contentType);
      $models = new ModelDiscovery();
      $model = "AppBundle\Model\\".$models->find([],$data->contentType);
      $contentModel = new $model;
      $contentModel->hydrate($data->content);
      $this->setContent(serialize($contentModel));
    }
    return null;
  }



}
