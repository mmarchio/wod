<?php
namespace AppBundle\Model\System;

use AppBundle\Model\Common;

class IndexTag extends Common
{
    protected $contentType;
    protected $contentTypeUuid;
    protected $field;
    protected $value;

    /**
     * @return string
     */
    final public function getContentType(): string
    {
        return $this->contentType;
    }

    /**
     * @param string $contentType
     * @return IndexTag
     */
    final public function setContentType(string $contentType): IndexTag
    {
        $this->contentType = $contentType;
        return $this;
    }

    /**
     * @return mixed
     */
    final public function getContentTypeUuid(): string
    {
        return $this->contentTypeUuid;
    }

    /**
     * @param mixed $contentTypeUuid
     * @return IndexTag
     */
    final public function setContentTypeUuid(string $contentTypeUuid): IndexTag
    {
        $this->contentTypeUuid = $contentTypeUuid;
        return $this;
    }

    /**
     * @return mixed
     */
    final public function getField(): string
    {
        return $this->field;
    }

    /**
     * @param mixed $field
     * @return IndexTag
     */
    final public function setField(string $field): IndexTag
    {
        $this->field = $field;
        return $this;
    }

    /**
     * @return mixed
     */
    final public function getValue()
    {
        return $this->value;
    }

    /**
     * @param mixed $value
     * @return IndexTag
     */
    final public function setValue($value): IndexTag
    {
        $this->value = $value;
        return $this;
    }

    
}