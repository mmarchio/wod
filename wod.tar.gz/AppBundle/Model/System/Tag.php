<?php
namespace AppBundle\Model\System;

use AppBundle\Model\Common;

class Tag extends Common
{
    protected $name;
    protected $type;
    protected $typeUuid;
    protected $parentUuid;
    protected $childUuid;

    /**
     * @return string
     */
    final public function getName(): string
    {
        return $this->name;
    }

    /**
     * @param string $name
     * @return Tag
     */
    final public function setName(string $name): Tag
    {
        $this->name = $name;
        return $this;
    }

    /**
     * @return string
     */
    final public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     * @return Tag
     */
    final public function setType(string $type): Tag
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @return string
     */
    final public function getTypeUuid(): string
    {
        return $this->typeUuid;
    }

    /**
     * @param string $typeUuid
     * @return Tag
     */
    final public function setTypeUuid(string $typeUuid): Tag
    {
        $this->typeUuid = $typeUuid;
        return $this;
    }

    /**
     * @return string
     */
    final public function getParentUuid(): string
    {
        return $this->parentUuid;
    }

    /**
     * @param string $parentUuid
     * @return Tag
     */
    final public function setParentUuid(string $parentUuid): Tag
    {
        $this->parentUuid = $parentUuid;
        return $this;
    }

    /**
     * @return string|null
     */
    final public function getChildUuid(): ?string
    {
        return $this->childUuid;
    }

    /**
     * @param string|null $childUuid
     * @return Tag
     */
    final public function setChildUuid(?string $childUuid): Tag
    {
        $this->childUuid = $childUuid;
        return $this;
    }
}