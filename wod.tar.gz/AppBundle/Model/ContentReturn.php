<?php
namespace AppBundle\Model;

class ContentReturn
{
  
}
