<?php
namespace AppBundle\Model;

use Symfony\Component\HttpFoundation\Request;

class Tag extends Common
{
  protected $name;
  protected $type;
  protected $type_uuid;

  public function __construct(Request $request)
  {
    $this->setName($request->get("name"));
    $this->setType($request->get("type"));
    $this->setTypeUuid($this->genUuid());
  }

  public function setName(string $name)
  {
    $this->name = $name;
    return $this;
  }

  public function getName()
  {
    return $this->name;
  }

  public function setType($type)
  {
    $this->type = $type;
    return $this;
  }

  public function getType()
  {
    return $this->type;
  }

  public function setTypeUuid($typeUuid)
  {
    $this->type_uuid = $typeUuid;
    return $this;
  }

  public function getTypeUuid()
  {
    return $this->type_uuid;
  }
}
