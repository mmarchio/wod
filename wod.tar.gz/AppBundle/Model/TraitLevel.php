<?php
namespace AppBundle\Model;

class TraitLevel
{
  protected $level;
  protected $description;
  protected $system;

  public function hydrate($object)
  {
    if (!empty($object->level)) {
      $this->setLevel($object->level);
    }
    if (!empty($object->description)) {
      $this->setDescription($object->description);
    }
    if (!empty($object->system)) {
      $this->setSystem($object->system);
    }
    if (!empty($object->uuid)) {
      $this->setUuid($object->uuid);
    }
    if (!empty($object->state)) {
      $this->setState($object->state);
    }
    if (!empty($object->version)) {
      $this->setVersion($object->version);
    }
    if (!empty($object->createdAt)) {
      $this->setCreatedAt($object->createdAt);
    }
    if (!empty($object->modifiedAt)) {
      $this->setModifiedAt($object->modifiedAt);
    }
    if (!empty($object->deletedAt)) {
      $this->setDeletedAt($object->deletedAt);
    }
    if (!empty($object->contentType)) {
      $this->setContentType($object->contentType);
    }
  }

  public function setLevel(int $level)
  {
    $this->level = $level;
    return $this;
  }

  public function getLevel()
  {
    return $this->name;
  }

  public function setDescription(string $description)
  {
    $this->description = $description;
    return $this;
  }

  public function getDescription()
  {
    return $this->description;
  }

  public function setSystem(string $system)
  {
    $this->system = $system;
    return $this;
  }

  public function getSystem()
  {
    return $this->system;
  }
}
