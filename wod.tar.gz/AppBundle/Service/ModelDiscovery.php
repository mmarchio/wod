<?php
namespace AppBundle\Service;

class ModelDiscovery
{
  public function find(array $excludes, ?string $needle = null)
  {
    dump($needle);
    if ($needle == "trait") {
      $needle = "traits";
    }
    $segments = explode("/", __DIR__);
    array_pop($segments);
    $path = implode("/", $segments)."/Model";
    $files = scandir($path);
    $c = count($files);
    $models = [];
    for($i=0; $i<$c; $i++) {
      if ($files[$i] == "." || $files[$i] == ".." || in_array($files[$i], $excludes)) {
        continue;
      }
      $model = str_replace(".php","",$files[$i]);
      if ($needle) {
        if (ucfirst($needle) == $model) {
          return $model;
        }
      }
      $models[] = $model;
    }
    return $models;
  }

  public function get(string $needle)
  {
      $modelString = "AppBundle\\Model\\Content\\$needle";
      return new $modelString;
  }
}
