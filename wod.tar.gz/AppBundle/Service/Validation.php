<?php
namespace AppBundle\Service;

use Symfony\Component\HttpFoundation\Request;

class Validation
{
    public function tag($tag)
    {
        $valid = true;
        if (is_string($tag)) {
          $tag = unserialize($tag);
        }
        if (empty($tag->getName())) {
            $valid = false;
        }

        if (empty($tag->getType())) {
            $valid = false;
        }

        return $valid;
    }

    public function tagUnion($tagUnion)
    {
      $valid = true;
      if (is_string($tagUnion)) {
        $tagUnion = unserialize($tagUnion);
      }
      if (empty($tagUnion->getEntity())) {
        $valid = false;
      }
      if (empty($tagUnion->getTag())) {
        $valid = false;
      }
      return $valid;
    }

    public function content($content)
    {
      $valid = true;
      if (is_string($content)) {
        $content = unserialize($content);
      }
      if (empty($content)) {
          $valid = false;
      }
      if (empty($content->getContentType())) {
          $valid = false;
      }
      switch ($content->getContentType()) {
          case "sect" :
              $valid = $this->sect($content);
              break;
          case "clan" :
              $valid = $this->clan($content);
              break;
          case "kindred" :
              break;
          case "human" :
              break;
          case "trait" :
              $valid = $this->traits($content);
              break;
          case "traitLevel" :
              $valid = $this->traitLevel($content);
              break;
          default :
              $valid = false;
              break;
      }
      return $valid;
    }

    public function sect($content)
    {
        $valid = true;
        if (empty($content->name)) {
          $valid = false;
        }
        return $valid;
    }

    public function clan($content)
    {
        $valid = true;
        if (empty($content->name)) {
            $valid = false;
        }
        if (empty($content->description)) {
            $valid = false;
        }
        if (empty($content->disciplines)) {
            $valid = false;
        }
        if (empty($content->weakness)) {
            $valid = false;
        }
        return $valid;
    }

    public function traits($content)
    {
        $valid = true;
        if (empty($content->getName())) {
            $valid = false;
        }
        if (empty($content->getType())) {
            $valid = false;
        }
        if (empty($content->getCategory())) {
            $valid = false;
        }
        return $valid;
    }

    public function traitLevel($content)
    {
        $valid = true;
        if (empty($content->getLevel())) {
            $valid = false;
        }
        if (empty($content->getDescription())) {
            $valid = false;
        }
        if (empty($content->getSystem())) {
            $valid = false;
        }
        return $valid;
    }
}
