<?php
namespace AppBundle\Service;


use AppBundle\Model\System\Content;
use AppBundle\Model\System\IndexTag;
use AppBundle\Model\System\Tag;

class DB
{
    private $conn;

    public function __construct($h, $u, $p, $d, $port = 3306)
    {
        $this->conn = new \mysqli($h, $u, $p, $d, $port);
    }

    public function q(string $q, string $type = "assoc")
    {
        $r = $this->conn->query($q);
        if (!empty($this->conn->errno)) {
            dump($this->conn->errno, $this->conn->error);
        }
        $data = [];
        if (!is_bool($r)) {
            switch ($type) {
                case "assoc":
                    while ($row = $r->fetch_assoc()) {
                        $data[] = $row;
                    }
                    break;
                case "array":
                    while ($row = $r->fetch_array()) {
                        $data[] = $row;
                    }
                    break;
            }
        }
        return $data;
    }

    public function pc(Content $content)
    {
        $fields = [
            "content_type",
            "content_type_uuid",
            "content"
        ];
        $fields = $this->getFields($fields);

        $values = [
            $content->getUuid(),
            $content->getVersion(),
            $content->getState(),
            $content->getVersionSetUuid(),
            $content->getCreatedAt(),
            $content->getModifiedAt(),
            $content->getContentType(),
            $content->getContentTypeUuid(),
            $content->getContent()
        ];

        $f = implode(", ", $fields);
        $v = '"'.implode('", "', $values).'"';
        $q = "INSERT INTO content ($f) VALUES ($v)";
        return $this->q($q);
    }

    public function rc(string $type)
    {
//        $q = "SELECT uuid, version_set_uuid, content FROM content where content_type = '$type'";
        $q = "SELECT uuid, content_type_uuid, value FROM index_tag WHERE content_type = '$type'";
        return $this->q($q);
    }

    public function persistIndexTag(IndexTag $tag)
    {
        $fields = $this->getIndexTagFields();
        $values = [
            $tag->getContentType(),
            $tag->getContentTypeUuid(),
            $tag->getField(),
            $tag->getValue()
        ];
        $values = $this->getValues($tag, $values);
        $fieldString = implode(", ", $fields);
        $valueString = '"'.implode('", "', $values).'"';
        $q = "INSERT INTO index_tag ($fieldString) VALUES ($valueString)";

        return $this->q($q);
    }

    public function persistIndexTags(array $tags)
    {
        $fields = implode(", ", $this->getIndexTagFields());
        $replacements = [
            "?", //uuid
            "?", //ver
            "?", //state
            "?", //vsu
            "?", //created
            "?", //modified
            "?", //ct
            "?", //ctu
            "?", //f
            "?" //val
        ];
        $replacements = implode(", ", $replacements);
        $q = "INSERT INTO index_tag ($fields) VALUES ($replacements)";
        $s = $this->conn->prepare($q);

        $this->conn->query("START TRANSACTION");
        foreach ($tags as $v) {
            $uuid = $v->getUuid();
            $version = $v->getVersion();
            $state = $v->getState();
            $vsu = $v->getVersionSetUuid();
            $c = $v->getCreatedAt();
            $m = $v->getModifiedAt();
            $ct = $v->getContentType();
            $ctu = $v->getContentTypeUuid();
            $f = $v->getField();
            $val = $v->getValue();
            $s->bind_param("sissssssss", $uuid, $version, $state, $vsu, $c, $m, $ct, $ctu, $f, $val);
            $s->execute();
        }
        $s->close();
        $this->conn->query("COMMIT");
    }

    private function getFields(array $content): array
    {
        $fields = [
            "uuid",
            "version",
            "state",
            "version_set_uuid",
            "created_at",
            "modified_at"
        ];
        return array_merge($fields, $content);
    }

    private function getValues($content, array $v): array
    {
        $values = [
            $content->getUuid(),
            $content->getVersion(),
            $content->getState(),
            $content->getVersionStateUuid(),
            $content->getCreatedAt(),
            $content->getModifiedAt()
        ];

        return array_merge($values, $v);
    }

    private function getIndexTagFields()
    {
        $fields = [
            "content_type",
            "content_type_uuid",
            "field",
            "value"
        ];
        return $this->getFields($fields);
    }

    private function getTagFields()
    {
        $fields = [
            'name',
            'type',
            'type_uuid',
            'parent_uuid',
            'child_uuid'
        ];
        return $this->getFields($fields);
    }

    public function persistTags(array $tags)
    {
        $fields = implode(", ", $this->getTagFields());
        $replacements = [
            "?", //uuid
            "?", //ver
            "?", //state
            "?", //vsu
            "?", //created
            "?", //modified
            "?", //name
            "?", //type
            "?", //type_uuid
            "?", //parent_uuid
            "?" //child_uuid
        ];
        $replacements = implode(", ", $replacements);
        $q = "INSERT INTO tag ($fields) VALUES ($replacements)";

        $s = $this->conn->prepare($q);
        $this->conn->query("START TRANSACTION");
        foreach ($tags as $v) {
            $uuid = $v->getUuid();
            $version = $v->getVersion();
            $state = $v->getState();
            $vsu = $v->getVersionSetUuid();
            $c = $v->getCreatedAt();
            $m = $v->getModifiedAt();
            $ct = $v->getName();
            $ctu = $v->getType();
            $f = $v->getTypeUuid();
            $val = $v->getParentUuid();
            $childUuid = $v->getChildUuid();
            $s->bind_param("sisssssssss", $uuid, $version, $state, $vsu, $c, $m, $ct, $ctu, $f, $val, $childUuid);
            $s->execute();
        }
        $s->close();
        $this->conn->query("COMMIT");
    }

    final public function getContent(string $uuid, string $rendition)
    {
        $q = "SELECT * FROM content WHERE uuid = '$uuid'";
        $content = $this->q($q);
        $object = null;

        switch ($rendition) {
            case "shallow":
                break;
            case "content":
                $object = new Content();
                $object->setContentType($content[0]['content_type'])
                    ->setContent($content[0]['content'])
                    ->setUuid($content[0]['uuid'])
                    ->setVersion($content[0]['version'])
                    ->setState($content[0]['state'])
                    ->setVersionSetUuid($content[0]['version_set_uuid'])
                    ->setCreatedAt($content[0]['created_at'])
                    ->setModifiedAt($content[0]['modified_at']);
                break;
            case "content-model":
                $object = new Content();
                $object->setContentType($content[0]['content_type'])
                    ->setContent(unserialize(base64_decode($content[0]['content'])))
                    ->setUuid($content[0]['uuid'])
                    ->setVersion($content[0]['version'])
                    ->setState($content[0]['state'])
                    ->setVersionSetUuid($content[0]['version_set_uuid'])
                    ->setCreatedAt($content[0]['created_at'])
                    ->setModifiedAt($content[0]['modified_at']);
                break;
            case "model":
                $object = unserialize(base64_decode($content[0]['content']));
                break;
        }
        return $object;
    }
}